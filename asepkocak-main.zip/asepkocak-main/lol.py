#!/usr/bin/env python3
# -*- coding:utf-8 -*-
import argparse
import io
import os
import re
import sys


def dequote(s):
    """
    If a string has single or double quotes around it, remove them.
    Make sure the pair of quotes match.
    If a matching pair of quotes is not found, return the string unchanged.
    """
    if (s[0] == s[-1]) and s.startswith(("'", '"')):
        return s[1:-1]
    return s


def clean(v):
    return re.sub(r"\s#[^\n]+", "", dequote(v.strip()))


def is_akia(v):
    return re.search("^(AKIA[A-Z0-9+]{16})$", v, re.IGNORECASE)


def Convert(lst):
    res_dct = {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
    return res_dct


def make_safe_filename(s):
    def safe_char(c):
        if c.isalnum():
            return c
        else:
            return "_"

    return "".join(safe_char(c) for c in s).rstrip("_")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        conflict_handler='resolve',
        description='Smtp profiler',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument('-l', action='store', dest='path',
                        help='List directory', default=None)
    parser.add_argument('-f', action='store', dest='file', help='extension: \'.jp,.com\'', default=None)
    args = parser.parse_args()
    PATH_ROOT = os.path.dirname(os.path.realpath(__file__))
    PATH_RESULT = os.path.join(PATH_ROOT, 'AWS')
    if 'path' in args and args.path:
        try:
            if not os.path.exists(PATH_RESULT):
                os.mkdir(PATH_RESULT)
            for root, dirs, files in os.walk(args.path):
                for file in files:
                    try:
                        the_file = os.path.join(root, file)
                        aws = {'host': os.path.basename(os.path.dirname(the_file)), 'key': None, 'secret': None,
                               'region': None}
                        with open(the_file, "r", encoding='utf8', errors='ignore') as myfile:
                            for line in myfile:
                                if not line.strip():
                                    continue
                                try:
                                    key, value = line.strip().split('=', 1)
                                    value = value.strip('\"\'')
                                    if not key:
                                        continue
                                    # print({key:value})
                                    if key == 'AWS_ACCESS_KEY_ID' and is_akia(value):
                                        aws.update(key=value)
                                    elif key == 'S3_ACCESS_KEY' and is_akia(value):
                                        aws.update(key=value)
                                    elif key == 'SES_KEY' and is_akia(value):
                                        aws.update(key=value)
                                    else:
                                        if re.search("key", key, re.IGNORECASE) and not aws.get('key') and is_akia(
                                                value):
                                            aws.update(key=value)
                                    if key == 'YOUR_AWS_SECRET_ACCESS_KEY':
                                        aws.update(secret=value)
                                    elif key == 'S3_SECRET_KEY':
                                        aws.update(secret=value)
                                    elif key == 'SES_SECRET':
                                        aws.update(secret=value)
                                    else:
                                        if re.search("secret", key, re.IGNORECASE) and not aws.get(
                                                'secret') and re.search(
                                            "^([A-Z0-9+\/\$\%_]{40})$", value, re.IGNORECASE):
                                            aws.update(secret=value)
                                    if key == 'AWS_REGION':
                                        aws.update(region=value)
                                    elif key == 'SES_REGION':
                                        aws.update(region=value)
                                    elif key == 'S3_REGION':
                                        aws.update(region=value)
                                    elif key == 'AWS_DEFAULT_REGION':
                                        aws.update(region=value)
                                    else:
                                        if re.search("region", key, re.IGNORECASE) and not aws.get('region'):
                                            aws.update(region=value)
                                except:
                                    pass
                        print(aws)
                        if aws.get('key'):
                            with open('AKIA.txt', 'a+') as rx:
                                rx.write(str('|').join(list(filter(None, aws.values()))))
                                rx.write('\n')
                    except Exception as e:
                        print('FATAL ERROR : %s' % e.message if hasattr(e, 'message') else str(e))
        except Exception as e:
            print('FATAL ERROR : %s' % e.message if hasattr(e, 'message') else str(e))
    if 'file' in args and args.file:
        try:
            if not os.path.exists(PATH_RESULT):
                os.mkdir(PATH_RESULT)
            delim = ''
            with open(args.file, "r", encoding='utf8', errors='ignore') as fd:
                data = fd.read()
                doms = re.findall(r"={31,}([^\=]+)={31,}", data, re.IGNORECASE)
                dats = re.split("={31,}[^\=]+={31,}", data)
                for i, dat in enumerate(dats):
                    if not dat:
                        continue
                    elif not dat.strip():
                        continue
                    aws = {'host': doms[i] if i < len(doms) else None, 'key': None, 'secret': None,
                           'region': None}
                    with io.StringIO(dat) as buf:
                        lines = buf.readlines()
                        for line in lines:
                            if not line.strip():
                                continue
                            try:
                                key, value = line.strip().split('=', 1)
                                if not isinstance(key, str) or not value:
                                    continue
                                value = value.strip('\"\'')
                                if key == 'AWS_ACCESS_KEY_ID' and is_akia(value):
                                    aws.update(key=value)
                                elif key == 'S3_ACCESS_KEY' and is_akia(value):
                                    aws.update(key=value)
                                elif key == 'SES_KEY' and is_akia(value):
                                    aws.update(key=value)
                                elif key == 's3WSAccessKeyId' and is_akia(value):
                                    aws.update(key=value)
                                else:
                                    if re.search("key", key, re.IGNORECASE) and is_akia(value):
                                        aws.update(key=value)
                                if key == 'YOUR_AWS_SECRET_ACCESS_KEY':
                                    aws.update(secret=value)
                                elif key == 'S3_SECRET_KEY':
                                    aws.update(secret=value)
                                elif key == 's3WSSecretAccessKey':
                                    aws.update(secret=value)
                                elif key == 'SES_SECRET':
                                    aws.update(secret=value)
                                else:
                                    if re.search("secret", key, re.IGNORECASE) and not aws.get('secret') and re.search(
                                            "^([A-Z0-9+\/\$\%_]{40})$", value, re.IGNORECASE):
                                        aws.update(secret=value)
                                if key == 'AWS_REGION':
                                    aws.update(region=value)
                                elif key == 'SES_REGION':
                                    aws.update(region=value)
                                elif key == 'S3_REGION':
                                    aws.update(region=value)
                                elif key == 'AWS_DEFAULT_REGION':
                                    aws.update(region=value)
                                else:
                                    if re.search("region", key, re.IGNORECASE) and not aws.get('region'):
                                        aws.update(region=value)
                            except:
                                pass
                    print(aws)
                    if aws.get('key'):
                        with open('AKIA.txt', 'a+') as rx:
                            rx.write(str('|').join(list(filter(None, aws.values()))))
                            rx.write('\n')
        except Exception as e:
            print('FATAL ERROR : %s' % e.message if hasattr(e, 'message') else str(e))
    else:
        parser.print_help()
        sys.exit(1)
